﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.SharedKernel.DomainModelLayer
{
    public interface IDomainService
    {
    }
}
