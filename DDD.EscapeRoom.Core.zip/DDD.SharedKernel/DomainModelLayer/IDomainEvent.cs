﻿namespace DDD.SharedKernel.DomainModelLayer
{
    public interface IDomainEvent
    {
        long Created { get; }
    }
}
