﻿using System;

namespace DDD.SharedKernel.DomainModelLayer
{
    public interface IAggregateRoot
    { }
}
