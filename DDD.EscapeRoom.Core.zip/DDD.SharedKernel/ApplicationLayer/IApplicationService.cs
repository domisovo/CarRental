﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.SharedKernel.ApplicationLayer
{
    public interface IApplicationService
    {
    }
}
