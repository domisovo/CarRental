﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetVisitQuery
    {
        public long VisitId { get; set; }
    }
}
