﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetAllCommentsForRoomQuery
    {
        public long RoomId { get; set; }
    }
}
