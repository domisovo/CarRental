﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetCommentQuery
    {
        public long CommentId { get; set; }
    }
}
