﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetAllPlayersQuery
    {
    }
}
