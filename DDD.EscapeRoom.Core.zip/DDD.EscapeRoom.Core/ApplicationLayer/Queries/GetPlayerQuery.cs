﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetPlayerQuery
    {
        public long PlayerId { get; set; }
    }
}
