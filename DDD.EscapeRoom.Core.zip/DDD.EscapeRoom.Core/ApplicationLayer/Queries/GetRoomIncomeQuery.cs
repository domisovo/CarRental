﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetRoomIncomeQuery 
    {
        public long RoomId { get; set; }
    }
}
