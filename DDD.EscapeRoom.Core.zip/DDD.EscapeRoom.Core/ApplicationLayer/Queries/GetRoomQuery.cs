﻿namespace DDD.EscapeRoom.Core.ApplicationLayer.Queries
{
    public class GetRoomQuery
    {
        public long RoomId { get; set; }
    }
}
